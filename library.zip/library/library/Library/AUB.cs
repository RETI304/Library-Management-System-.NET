﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class AUB : Form
    {
        public AUB()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AI form = new AI();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=library;Integrated Security=True");
            int booid = int.Parse(bi.Text);
            string bname = bn.Text;
            string aname = an.Text;
            int stock= int.Parse(bs.Text);
            SqlCommand cmd = new SqlCommand("Update books set bookname = '" + bname + "',author = '" + aname + "',stock = " + stock + " where bookid = " + booid + "", con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((result != 0) ? "Register Successfully" : "not Saved");
            bi.Clear();
            bn.Clear();
            an.Clear();
            bs.Clear();
        }
    }
}
