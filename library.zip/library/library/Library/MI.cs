﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class MI : Form
    {
        public MI()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=library;Integrated Security=True");
        
        private void button1_Click(object sender, EventArgs e)
        {
            string name = un.Text;
            string pass = up.Text;
            if (name.Equals("") || pass.Equals("") )
            {
                MessageBox.Show("Please Fill all Colums");
            }
            else
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO admin  VALUES ('" + name + "', '" + pass + "' )", con);

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show((result != 0) ? "Register Successfully" : "not Saved");
                un.Clear();
                up.Clear();
               

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = mn.Text;
            string pass = mp.Text;
            if (name.Equals("") || pass.Equals(""))
            {
                MessageBox.Show("Please Fill all Colums");
            }
            else
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO management  VALUES ('" + name + "', '" + pass + "' )", con);

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show((result != 0) ? "Register Successfully" : "not Saved");
                mn.Clear();
                mp.Clear();


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }
    }
}
