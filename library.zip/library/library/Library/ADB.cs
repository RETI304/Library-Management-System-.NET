﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class ADB : Form
    {
        public ADB()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AI Form = new AI();
            Form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=library;Integrated Security=True");
            int booid = int.Parse(textBox1.Text);
            SqlCommand cmd = new SqlCommand("Delete  books where bookid="+booid+"",con);
            con.Open();
            int result =cmd.ExecuteNonQuery();
            MessageBox.Show((result != 0) ? "Book Deleted" : "Book Not Found");
        }
    }
}
