﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Library
{
    public partial class VB : Form
    {
        public VB()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            UI form = new UI();
            form.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=library;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter cmd = new SqlDataAdapter("Select * from books", con);
            DataTable dt = new DataTable();
            cmd.Fill(dt);
            res.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int booid = int.Parse(bi.Text);
          
            
                SqlDataAdapter da = new SqlDataAdapter("Select * from books where bookid="+booid+"",con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                res.DataSource = dt;
            
        }
    }
}
