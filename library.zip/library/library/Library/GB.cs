﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class GB : Form
    {
        public GB()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            UI Form = new UI();
            Form.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=library;Integrated Security=True");
            int booid = int.Parse(textBox1.Text);
            int nobook = int.Parse(textBox2.Text);
            if (nobook > 0)
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Update books set stock = stock - "+nobook+" where bookid = "+booid+"",con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Book Geted");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
