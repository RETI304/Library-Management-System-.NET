﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class AL : Form
    {
        public AL()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=library;Integrated Security=True");
            string name = textBox1.Text;
            string pass = textBox2.Text;

            if (name.Equals("") || pass.Equals(""))
            {
                MessageBox.Show("Please Fill all Colums");
            }
            else
            {
                SqlCommand query = new SqlCommand("select count(*) from admin where username = '" + name + "' and password = '" + pass + "'", con);
                con.Open();
                int count = (int)query.ExecuteScalar();

                if (count != 0)
                {
                    MessageBox.Show("Login Succesfully");
                    this.Hide();
                    AI Form = new AI();
                    Form.Show();
                    textBox1.Clear();
                    textBox2.Clear();
                }
                else
                {
                    MessageBox.Show("Please Enter Correct Username or Password");
                }

            }
        }
    }
}
