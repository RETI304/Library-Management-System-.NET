﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class R : Form
    {
        public R()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=library;Integrated Security=True");
            string name = un.Text;
            string pass = up.Text;
            string d = dob.Text;
            if(name.Equals("") || pass.Equals("")|| d.Equals(""))
            {
                MessageBox.Show("Please Fill all Colums");
            }
            else
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO users  VALUES ('"+name+"', '"+pass+ "','"+d+"' )", con);
   
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show((result !=0)?"Register Successfully":"not Saved");
                un.Clear();
                up.Clear();
                dob.Clear();
                this.Hide();
                UL uL = new UL();
                uL.Show();
                
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();


            
        }

        private void R_Load(object sender, EventArgs e)
        {

        }
    }
}
