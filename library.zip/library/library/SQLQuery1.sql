create table users (username varchar(100),password varchar(100),dob varchar(100))
create table admin (username varchar(100),password varchar(100))
create table management (username varchar(100),password varchar(100))
create table books (bookid int,bookname varchar(100),author varchar(100),stock int)